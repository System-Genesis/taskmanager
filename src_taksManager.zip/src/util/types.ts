export type axiosReq = 'GET' | 'POST';
